import 'package:firebase_core/firebase_core.dart' show Firebase;
import 'package:firebase_remote_config/firebase_remote_config.dart';

//ads
const String bannerAdAndroid = "ADMOB_BANNER";
const String interstitialAdAndroid = "ADMOB_INTERSTITIAL";
const String nativeAdAndroid = "ADMOB_NATIVE";
const String appOpenAd = "_APP_OPEN";
const String _isAdEnable = "IS_AD_ENABLE";

//website_controls
const String _thaiPeople = "THAI_PEOPLE";
const String _foreigner = "FOREIGNER";
const String _webView = "WEBVIEW";

// API LINK
const String _rssFeedUrl = "RSSFEEDURL";

class RemoteConfigService {
  final FirebaseRemoteConfig _remoteConfig;

  RemoteConfigService({required FirebaseRemoteConfig remoteConfig})
      : _remoteConfig = remoteConfig;

  final defaults = <String, dynamic>{
    bannerAdAndroid: "ca-app-pub-3940256099942544/6300978111",
    interstitialAdAndroid: "ca-app-pub-3940256099942544/1033173712",
    nativeAdAndroid: "ca-app-pub-3940256099942544/2247696110",
    appOpenAd: "ca-app-pub-3940256099942544/3419835294",
    _rssFeedUrl: 'http://www.dlt.go.th/th/public-news/rss.xml',
    _isAdEnable: true,
  };

  static RemoteConfigService? _instance;

  static Future<RemoteConfigService?> getInstance() async {
    await Firebase.initializeApp();
    _instance = RemoteConfigService(
      // ignore: await_only_futures
      remoteConfig: await FirebaseRemoteConfig.instance,
    );
    return _instance;
  }

  String get getBannerAdsId => _remoteConfig.getString(bannerAdAndroid);

  String get getInterstitialAdId =>
      _remoteConfig.getString(interstitialAdAndroid);

  String get getNativeAdId => _remoteConfig.getString(nativeAdAndroid);

  String get getAppOpenId => _remoteConfig.getString(appOpenAd);

  String get getRssFeedUrl => _remoteConfig.getString(_rssFeedUrl);

  bool get getAdIsEnable => _remoteConfig.getBool(_isAdEnable);

  Future initialize() async {
    try {
      await _remoteConfig.setDefaults(defaults);
      await _fetchAndActive();
    } catch (e) {}
  }

  Future _fetchAndActive() async {
    await _remoteConfig.fetch();
    await _remoteConfig.setConfigSettings(RemoteConfigSettings(
        fetchTimeout: const Duration(seconds: 0),
        minimumFetchInterval: const Duration(milliseconds: 500)));
    await _remoteConfig.fetchAndActivate();
  }
}
