import 'dart:convert' show utf8;

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http show Client;
import 'package:webfeed/domain/rss_feed.dart' show RssFeed;

import '../appConstant.dart';

class RssTab extends StatefulWidget {
  const RssTab({Key? key}) : super(key: key);

  @override
  State<RssTab> createState() => _RssTabState();
}

class _RssTabState extends State<RssTab> {
  RssFeed _feed = RssFeed();
  bool isLoading = false;

  Future<RssFeed?> getdata() async {
    try {
      final client = http.Client();
      final response = await client.get(
          Uri.parse('https://www.bot.or.th/App/RSSFeed/News.aspx?lang=th'));

      var r = RssFeed.parse(utf8.decode(response.bodyBytes));
      _feed = r;

      isLoading = true;
      setState(() {});
    } catch (e) {
      debugPrint('$e');
    }
    return null;
  }

  @override
  void initState() {
    super.initState();
    getdata();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isLoading
          ? ListView.builder(
              padding: const EdgeInsets.only(bottom: 13, top: 13),
              itemCount: _feed.items!.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8.0,
                  ),
                  child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      color: AppColors.clrWhite54,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: ExpansionTile(
                          title: Text(
                            '${_feed.items![index].title}',
                            textAlign: TextAlign.justify,
                            style: TextStyle(
                              color: AppColors.clrBlack,
                            ),
                          ),
                          subtitle: Padding(
                            padding: const EdgeInsets.only(top: 10.0),
                            child: Text(
                              timeAgo(_feed.items![index].dc!.date),
                              style: TextStyle(color: AppColors.clrBlack),
                            ),
                          ),
                          children: [
                            ListTile(
                              title: Text('${_feed.items![index].description}'),
                            )
                          ],
                        ),
                      )),
                );
              },
            )
          : const Center(
              child: CircularProgressIndicator(),
            ),
    );
  }

  String timeAgo(d) {
    Duration diff = DateTime.now().difference(d);
    if (diff.inDays > 365) {
      return "${(diff.inDays / 365).floor()} ${(diff.inDays / 365).floor() == 1 ? "year" : "years"} ago";
    }
    if (diff.inDays > 30) {
      return "${(diff.inDays / 30).floor()} ${(diff.inDays / 30).floor() == 1 ? "month" : "months"} ago";
    }
    if (diff.inDays > 7) {
      return "${(diff.inDays / 7).floor()} ${(diff.inDays / 7).floor() == 1 ? "week" : "weeks"} ago";
    }
    if (diff.inDays > 0) {
      return "${diff.inDays} ${diff.inDays == 1 ? "day" : "days"} ago";
    }
    if (diff.inHours > 0) {
      return "${diff.inHours} ${diff.inHours == 1 ? "hour" : "hours"} ago";
    }
    if (diff.inMinutes > 0) {
      return "${diff.inMinutes} ${diff.inMinutes == 1 ? "minute" : "minutes"} ago";
    }
    return "just now";
  }
}
