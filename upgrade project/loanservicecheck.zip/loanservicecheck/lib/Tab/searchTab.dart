import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:url_launcher/url_launcher.dart' show LaunchMode, launchUrl;

import '../Helper/nativeAd.dart';
import '../appConstant.dart';
import '../screen/homeScreen.dart';
import '../screen/plashScreen.dart';

class SearchTab extends StatefulWidget {
  const SearchTab({Key? key}) : super(key: key);

  @override
  State<SearchTab> createState() => _SearchTabState();
}

class _SearchTabState extends State<SearchTab> {
  TextEditingController searchText = TextEditingController();
  TextEditingController searchText1 = TextEditingController();
  var dbRef = FirebaseDatabase.instance.ref();
  List searchData = [];
  bool isLoading = false;
  NativeAd? nativeAd2;
  bool nativeAdIsLoaded = false;
  Future<void> _createAds() async {
    if (isAdEnable == true) {
      nativeAd2 = await buildNativeAd(() {
        setState(() {
          nativeAdIsLoaded = true;
        });
      }, factoryId: "regularNative")
        ..load();
    }
  }

  @override
  void initState() {
    super.initState();
    _createAds();
  }

  @override
  void dispose() {
    nativeAd2?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      extendBody: true,
      body: ListView(
        children: [
          const SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.only(right: 15.0, left: 15.0, bottom: 15),
            child: SizedBox(
              height: 50,
              child: TextField(
                  decoration: InputDecoration(
                      labelText: 'Search',
                      contentPadding:
                          const EdgeInsets.symmetric(horizontal: 10),
                      labelStyle: TextStyle(
                          fontSize: 14,
                          color: Colors.grey.shade400,
                          fontWeight: FontWeight.w600),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide(color: Colors.grey.shade300),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                        borderSide: BorderSide(color: AppColors.clrBlack38),
                      ),
                      floatingLabelBehavior: FloatingLabelBehavior.auto,
                      suffixIcon: IconButton(
                          onPressed: () {
                            getSearchData(searchText1.text.toUpperCase());
                            isLoading = true;
                          },
                          icon: Icon(
                            Icons.search,
                            color: AppColors.clrBlack38,
                            size: 30,
                          ))),
                  key: const ValueKey('search'),
                  keyboardType: TextInputType.text,
                  controller: searchText,
                  onChanged: (value) {
                    searchText1.text = value;
                  }),
            ),
          ),
          SizedBox(
            height: MediaQuery.of(context).size.height,
            child: ListView(
              children: [
                isLoading
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : ListView.builder(
                        itemCount: searchData.length,
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          debugPrint(
                              '-----data-----${searchData[index]['appname']}');
                          if (searchData.isNotEmpty) {
                            return Padding(
                              padding: const EdgeInsets.only(
                                  top: 4.0, left: 5, right: 5),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                    borderRadius: const BorderRadius.all(
                                        Radius.circular(12)),
                                    side: BorderSide(
                                        color: AppColors.clrBlack38)),
                                child: SizedBox(
                                  height: 80,
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      SizedBox(
                                        width: 2.w,
                                      ),
                                      CircleAvatar(
                                          radius: 35,
                                          backgroundColor: AppColors.clrWhite,
                                          child: searchData[index]
                                                      ['logo_image'] !=
                                                  'null'
                                              ? Image.network(
                                                  '${searchData[index]['logo_image']}',
                                                  loadingBuilder:
                                                      (BuildContext context,
                                                          Widget child,
                                                          ImageChunkEvent?
                                                              loadingProgress) {
                                                    if (loadingProgress ==
                                                        null) {
                                                      return child;
                                                    }
                                                    return Center(
                                                      child:
                                                          CircularProgressIndicator(
                                                        value: loadingProgress
                                                                    .expectedTotalBytes !=
                                                                null
                                                            ? loadingProgress
                                                                    .cumulativeBytesLoaded /
                                                                loadingProgress
                                                                    .expectedTotalBytes!
                                                            : null,
                                                      ),
                                                    );
                                                  },
                                                  errorBuilder: (context, error,
                                                      stackTrace) {
                                                    return Image.asset(
                                                        'assest/images/ic_default_bank_image.jpg');
                                                  },
                                                )
                                              : Image.asset(
                                                  'assest/images/ic_default_bank_image.jpg')),
                                      SizedBox(
                                        width: 2.w,
                                      ),
                                      searchData[index]['appname'] == 'null'
                                          ? SizedBox(
                                              width: 23.w,
                                            )
                                          : SizedBox(
                                              width: 23.w,
                                              child: Text(
                                                  '${searchData[index]['appname']}')),
                                      MaterialButton(
                                        color: AppColors.clrBlack,
                                        onPressed: () {
                                          FocusScope.of(context).unfocus();
                                          showDialog(
                                            context: context,
                                            builder: (context) =>
                                                buildSearchDialog(context,
                                                    searchData[index]['url']),
                                          );
                                        },
                                        child: Text(
                                          'Link',
                                          style: TextStyle(
                                              color: AppColors.clrWhite,
                                              fontSize: 16.sp),
                                        ),
                                      ),
                                      SizedBox(
                                        width: 2.w,
                                      ),
                                      Flexible(
                                          child: Text(
                                              '${searchData[index]['service_provider']}')),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          } else {
                            return const Center(child: Text('No Data Found'));
                          }
                        },
                      ),
                SizedBox(
                  height: searchData.isEmpty ? 28.h : 2.h,
                ),
                (isAdEnable == true && nativeAdIsLoaded)
                    ? SizedBox(
                        height: MediaQuery.of(context).size.height * 0.33,
                        width: MediaQuery.of(context).size.width * 0.75,
                        child: AdWidget(ad: nativeAd1!))
                    : const SizedBox.shrink(),
                SizedBox(
                  height: searchData.isEmpty
                      ? 0.h
                      : MediaQuery.of(context).size.height * 0.33,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  getSearchData(searchText) async {
    searchData.clear();
    DatabaseReference bankData = FirebaseDatabase.instance.ref().child('bank');
    DatabaseReference nonBankData =
        FirebaseDatabase.instance.ref().child('non_Bank');
    await getBankData(bankData, searchText);
    await getNonBankData(nonBankData, searchText);
  }

  getBankData(DatabaseReference bankData, searchText) {
    bankData.once().then((bankData) {
      List search = [];
      for (var element in bankData.snapshot.children) {
        Map data = element.value as Map;
        if (data['appname']
            .toString()
            .toUpperCase()
            .contains(searchText.toString())) {
          debugPrint('+++++bank+++++${data['appname']}');
          search.add(data);

          searchData = search.uniques;
        }
      }
    }).then((value) => setState(() {}));
  }

  getNonBankData(DatabaseReference nonBankData, searchText) {
    nonBankData.once().then((nonBankData) {
      List search = [];
      for (var element in nonBankData.snapshot.children) {
        Map nonBankData = element.value as Map;
        if (nonBankData['appname']
            .toString()
            .toUpperCase()
            .contains(searchText.toString())) {
          debugPrint('+++++non-bank+++++${nonBankData['appname']}');
          search.add(nonBankData);
          searchData = search.uniques;
        }
      }
    }).then((value) => setState(() {
          isLoading = false;
        }));
  }

  buildSearchDialog(BuildContext context, String searchData) {
    var media = MediaQuery.of(context),
        width = media.size.width,
        height = media.size.height;
    return Dialog(child: StatefulBuilder(
      builder: (context, setState) {
        return SizedBox(
          height: (isAdEnable == true && nativeAdIsLoaded)
              ? height * 0.50
              : height * 0.20,
          child: Column(
            children: [
              (isAdEnable == true && nativeAdIsLoaded)
                  ? SizedBox(
                      height: height * 0.33,
                      width: width * 0.75,
                      child: AdWidget(ad: nativeAd2!))
                  : const SizedBox.shrink(),
              SizedBox(
                height: 1.h,
              ),
              Flexible(
                child: SingleChildScrollView(
                  child: Container(
                      padding: const EdgeInsets.all(10),
                      width: 65.w,
                      height: searchData.length < 32
                          ? height < 700
                              ? 6.h
                              : 5.h
                          : height < 700
                              ? 9.h
                              : 10.h,
                      decoration: BoxDecoration(
                          border: Border.all(color: AppColors.clrBlack38),
                          borderRadius: BorderRadius.circular(5)),
                      child: Center(
                          child: Text(
                        searchData == 'null' ? 'url not available' : searchData,
                        style: const TextStyle(fontSize: 16),
                      ))),
                ),
              ),
              SizedBox(
                height: 1.h,
              ),
              searchData == 'null'
                  ? const SizedBox.shrink()
                  : SizedBox(
                      width: 65.w,
                      child: OutlinedButton(
                          onPressed: () {
                            launchUrl(Uri.parse(searchData),
                                mode: LaunchMode.externalApplication);
                            Navigator.pop(context);
                          },
                          style: OutlinedButton.styleFrom(
                              primary: AppColors.clrBlack,
                              side: BorderSide(color: AppColors.clrBlack38)),
                          child: const Text('Go To Website')),
                    ),
              SizedBox(
                height: 1.h,
              ),
            ],
          ),
        );
      },
    ));
  }
}
