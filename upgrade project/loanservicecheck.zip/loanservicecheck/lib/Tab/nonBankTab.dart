import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:responsive_sizer/responsive_sizer.dart';

import '../appConstant.dart';
import '../screen/homeScreen.dart';

class NonBankTab extends StatefulWidget {
  const NonBankTab({Key? key}) : super(key: key);

  @override
  State<NonBankTab> createState() => _NonBankTabState();
}

class _NonBankTabState extends State<NonBankTab> {
  late DatabaseReference databaseReference;
  late final ref = FirebaseDatabase.instance.ref().child('non_Bank');
  var realList = [], list = [], currentIndex = 0;

  void data() {
    ref.once().then((e) {
      debugPrint('---------${e.snapshot.value}');
      if (mounted) setState(() {});
    });
  }

  void getNonBankData(DatabaseReference nonBankData) {
    nonBankData.once().then((nonBankData) {
      for (var element in nonBankData.snapshot.children) {
        Map nonBankData = element.value as Map;
        realList.add(nonBankData);
      }
    });
  }

  @override
  void initState() {
    getNonBankData(ref);
    super.initState();
    data();
    databaseReference = ref;
    list = realList;
  }

  @override
  Widget build(BuildContext context) {
    var listIndex = (realList.length / 30).ceil(),
        start = currentIndex * 30,
        end = (currentIndex + 1) * 30;
    list = realList.isNotEmpty
        ? realList.sublist(start, currentIndex == listIndex - 1 ? null : end)
        : [];
    var length = list.length < 30 ? list.length : 30,
        rl = realList.length % 30,
        endIndex = rl == 0 ? end : currentIndex * 30 + rl;
    return Scaffold(
      body: Column(
        children: [
          Flexible(
            child: Builder(
              builder: (context) {
                if (list.isEmpty) {
                  return const Center(child: CircularProgressIndicator());
                } else {
                  return ListView.builder(
                    itemBuilder: (context, index) {
                      return Padding(
                        padding:
                            const EdgeInsets.only(top: 4.0, left: 5, right: 5),
                        child: Card(
                          shape: RoundedRectangleBorder(
                              borderRadius:
                                  const BorderRadius.all(Radius.circular(12)),
                              side: BorderSide(color: AppColors.clrBlack38)),
                          child: SizedBox(
                            height: 80,
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                SizedBox(
                                  width: 2.w,
                                ),
                                CircleAvatar(
                                    radius: 35,
                                    backgroundColor: AppColors.clrWhite,
                                    child: Image.network(
                                      '${list[index]['logo_image']}',
                                      errorBuilder:
                                          (context, error, stackTrace) {
                                        return Image.asset(
                                            'assest/images/ic_default_bank_image.jpg');
                                      },
                                    )),
                                SizedBox(
                                  width: 2.w,
                                ),
                                list[index]['appname'] == 'null'
                                    ? SizedBox(
                                        width: 23.w,
                                      )
                                    : SizedBox(
                                        width: 23.w,
                                        child:
                                            Text('${list[index]['appname']}')),
                                MaterialButton(
                                  color: AppColors.clrBlack,
                                  onPressed: () {
                                    showDialog(
                                      context: context,
                                      builder: (context) => buildPopupDialog(
                                          context, list[index]),
                                    );
                                  },
                                  child: Text(
                                    'Link',
                                    style: TextStyle(
                                        color: AppColors.clrWhite,
                                        fontSize: 16.sp),
                                  ),
                                ),
                                SizedBox(
                                  width: 2.w,
                                ),
                                Expanded(
                                    child: Text(
                                        '${list[index]['service_provider']}')),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                    itemCount: length,
                  );
                }
              },
            ),
          ),
          if (list.isNotEmpty)
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                IconButton(
                  onPressed: currentIndex == 0
                      ? () {}
                      : () => setState(() => currentIndex--),
                  icon: CircleAvatar(
                    backgroundColor: currentIndex == 0
                        ? Colors.white10
                        : Colors.blueGrey[100],
                    child: Icon(
                      Icons.arrow_back,
                      color: currentIndex == 0 ? Colors.black38 : Colors.black,
                    ),
                  ),
                ),
                Text(
                  '${start + 1}  -  ${currentIndex == listIndex - 1 ? endIndex : end}',
                ),
                IconButton(
                  onPressed: currentIndex == listIndex - 1
                      ? () {}
                      : () => setState(() => currentIndex++),
                  icon: CircleAvatar(
                    backgroundColor: currentIndex == listIndex - 1
                        ? Colors.white10
                        : Colors.blueGrey[100],
                    child: Icon(
                      Icons.arrow_forward,
                      color: currentIndex == listIndex - 1
                          ? Colors.black38
                          : Colors.black,
                    ),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }
}
