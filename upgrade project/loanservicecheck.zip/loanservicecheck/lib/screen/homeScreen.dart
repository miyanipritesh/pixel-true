import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:url_launcher/url_launcher.dart' show LaunchMode, launchUrl;

import '../Helper/bannerAd.dart';
import '../Helper/nativeAd.dart';
import '../Tab/bankTab.dart';
import '../Tab/nonBankTab.dart';
import '../Tab/rssTab.dart';
import '../Tab/searchTab.dart';
import '../appConstant.dart';
import 'plashScreen.dart';

// NativeAd? nativeAd3;
// bool nativeAdIsLoaded1 = false;
NativeAd? nativeAd1;
bool nativeAdIsLoaded = false;

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  int currentIndex = 0;

  int? currentIndex1;
  late TabController tabController;

  Future<void> _createAds() async {
    if (isAdEnable == true) {
      nativeAd1 = await buildNativeAd(() {
        setState(() {
          nativeAdIsLoaded = true;
        });
      }, factoryId: "regularNative")
        ..load();
    }
  }

  @override
  void initState() {
    super.initState();
    _createAds();
    tabController = TabController(length: 4, vsync: this, initialIndex: 0);
  }

  @override
  void dispose() {
    nativeAd1?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
      child: Column(
        children: [
          isAdEnable == true ? const AdBannerAd() : const SizedBox.shrink(),
          Padding(
            padding: const EdgeInsets.only(top: 10.0, bottom: 10),
            child: Container(
              height: 50,
              margin: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                color: AppColors.clrBlack26,
                borderRadius: BorderRadius.circular(50),
              ),
              child: TabBar(
                controller: tabController,
                padding: const EdgeInsets.all(7),
                indicator: BoxDecoration(
                    borderRadius: BorderRadius.circular(50),
                    color: AppColors.clrWhite),
                labelColor: AppColors.clrBlack,
                unselectedLabelColor: AppColors.clrBlack,
                tabs: const [
                  Tab(
                    child: Text(
                      'Non_Bank',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
                    ),
                  ),
                  Tab(
                    child: Text(
                      'Bank',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
                    ),
                  ),
                  Tab(
                    child: Text(
                      'Search',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
                    ),
                  ),
                  Tab(
                    child: Text(
                      'Rss',
                      style:
                          TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
                    ),
                  ),
                ],
                labelStyle:
                    const TextStyle(fontWeight: FontWeight.w500, fontSize: 14),
              ),
            ),
          ),
          Expanded(
            child: TabBarView(
              controller: tabController,
              children: const [NonBankTab(), BankTab(), SearchTab(), RssTab()],
            ),
          ),
        ],
      ),
    ));
  }
}

Widget buildPopupDialog(BuildContext context, Map data) {
  var media = MediaQuery.of(context),
      height = media.size.height,
      width = media.size.width;
  return Dialog(
      // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.0)),
      insetPadding: EdgeInsets.zero,
      child: StatefulBuilder(
        builder: (context, setState) {
          final url = data['url'] as String;
          return SizedBox(
            height: (isAdEnable == true && nativeAdIsLoaded)
                ? url.length < 32
                    ? height < 700
                        ? height * 0.52
                        : height * 0.48
                    : height < 700
                        ? height * 0.48
                        : height * 0.50
                : height * 0.20,
            // width: MediaQuery.of(context).size.width * 0.75,
            child: Column(
              children: [
                (isAdEnable == true && nativeAdIsLoaded)
                    ? SizedBox(
                        height: height * 0.33,
                        width: width * 0.75,
                        child: AdWidget(ad: nativeAd1!))
                    : const SizedBox.shrink(),
                SizedBox(
                  height: (isAdEnable == true && nativeAdIsLoaded)
                      ? 1.h
                      : url.length < 32
                          ? 3.h
                          : 2.h,
                ),
                Flexible(
                  child: Container(
                      padding: const EdgeInsets.only(left: 3, top: 5),
                      width: 60.w,
                      height: url.length < 32
                          ? height < 700
                              ? 9.h
                              : 5.5.h
                          : height < 700
                              ? 16.h
                              : 10.h,
                      decoration: BoxDecoration(
                          border: Border.all(color: AppColors.clrBlack38),
                          borderRadius: BorderRadius.circular(5)),
                      child: SingleChildScrollView(
                        child: Center(
                            child: Text(
                          url == 'null' ? 'url not available' : url,
                          style: const TextStyle(fontSize: 17),
                        )),
                      )),
                ),
                SizedBox(height: 1.h),
                url == 'null'
                    ? const SizedBox.shrink()
                    : SizedBox(
                        width: 60.w,
                        child: OutlinedButton(
                            onPressed: () {
                              launchUrl(Uri.parse(url),
                                  mode: LaunchMode.externalApplication);
                              Navigator.pop(context);
                            },
                            style: OutlinedButton.styleFrom(
                                primary: AppColors.clrBlack,
                                side: BorderSide(color: AppColors.clrBlack38)),
                            child: const Text('Go To Website')),
                      ),
                SizedBox(height: 1.h),
              ],
            ),
          );
        },
      ));
}
