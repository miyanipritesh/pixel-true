import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart' show AdWidget;
import 'package:responsive_sizer/responsive_sizer.dart';
import 'package:store_redirect/store_redirect.dart';

import '../Helper/bannerAd.dart';
import '../Helper/intertitialAd.dart';
import '../appConstant.dart';
import 'InstructionScreen.dart';
import 'homeScreen.dart';
import 'plashScreen.dart';

enum Availability { loading, available, unavailable }

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({Key? key}) : super(key: key);

  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  final AdShowHelper _adShowHelper = AdShowHelper();

  // todo:_createAds

  @override
  void initState() {
    super.initState();
    // _createAds();
    _adShowHelper.createInterstitialAd();
  }

  @override
  void dispose() {
    super.dispose();
    nativeAd2?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: ListView(
          children: [
            (isAdEnable == true) ? const AdBannerAd() : const SizedBox.shrink(),
            SizedBox(
              height: 6.h,
            ),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 5.w),
              child: Text(
                'The app provide loan service check for you, and this app give best experience, so share your experience to use over app',
                style: TextStyle(
                    fontWeight: FontWeight.w400,
                    color: AppColors.clrBlack,
                    fontSize: 17.sp),
              ),
            ),
            SizedBox(
              height: 6.h,
            ),
            (nativeAd2 != null && nativeAdIsLoaded1)
                ? SizedBox(
                    height: MediaQuery.of(context).size.height * 0.33,
                    width: MediaQuery.of(context).size.width * 0.70,
                    child: AdWidget(ad: nativeAd2!),
                  )
                : const SizedBox.shrink(),
            SizedBox(
              height: 2.h,
            ),
            UnconstrainedBox(
              child: SizedBox(
                height: 5.h,
                width: 65.w,
                child: ElevatedButton(
                    style: ButtonStyle(
                        shape: MaterialStateProperty.all(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8))),
                        elevation: MaterialStateProperty.all(0),
                        backgroundColor:
                            MaterialStateProperty.all(AppColors.clrBlack)),
                    onPressed: () {
                      StoreRedirect.redirect(
                          androidAppId: "com.app.loanservicecheck");
                    },
                    child: Text(
                      AppString.strReview,
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: AppColors.clrWhite,
                          fontSize: 18.sp),
                    )),
              ),
            ),
            SizedBox(
              height: 5.h,
            ),
            UnconstrainedBox(
              child: SizedBox(
                height: 5.h,
                width: 65.w,
                child: ElevatedButton(
                    style: ButtonStyle(
                        shape: MaterialStateProperty.all(RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8))),
                        elevation: MaterialStateProperty.all(0),
                        backgroundColor:
                            MaterialStateProperty.all(AppColors.clrBlack)),
                    onPressed: () {
                      if (isAdEnable == true) {
                        _adShowHelper.showInterstitialAd();
                      }

                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                            builder: (context) => const HomeScreen(),
                          ));
                    },
                    child: Text(
                      AppString.strStart,
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: AppColors.clrWhite,
                          fontSize: 18.sp),
                    )),
              ),
            )
          ],
        ),
      ),
    );
  }
}
