package com.app.loanservicecheck

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugins.googlemobileads.GoogleMobileAdsPlugin


class MainActivity: FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        val factory: GoogleMobileAdsPlugin.NativeAdFactory = RegularNativeAd(layoutInflater)
        GoogleMobileAdsPlugin.registerNativeAdFactory(flutterEngine, "regularNative", factory)

    }
    override fun cleanUpFlutterEngine(flutterEngine: FlutterEngine) {
        GoogleMobileAdsPlugin.unregisterNativeAdFactory(flutterEngine, "regularNative")
    }
}
